import { Component } from '@angular/core';

@Component({
  selector: 'app-failed-to-pay',
  templateUrl: './failed-to-pay.component.html',
  styleUrls: ['./failed-to-pay.component.scss']
})
export class FailedToPayComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-stopleaks',
  templateUrl: './stopleaks.component.html',
  styleUrls: ['./stopleaks.component.scss']
})
export class StopleaksComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-biteback',
  templateUrl: './biteback.component.html',
  styleUrls: ['./biteback.component.scss']
})
export class BitebackComponent {

}

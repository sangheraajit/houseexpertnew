import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { httpService } from 'src/app/service/http.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  plumber = '../../../../assets/images/plumber-making.png';
  cheerful = '../../../../assets/images/cheerful-delivery.png';
  tender = '../../../../assets/images/tender.png';
  shapblue ='../../../../assets/images/purple-shape.svg';
  shappink ='../../../../assets/images/pink-shape.svg';
  outsideplace = '../../../../assets/images/hand-presenting.png'

  CategoryList: any;
  FeaturedPartnerList: any;
  fragment: any;

  constructor(private apiservice: httpService, private route: ActivatedRoute) {

    this.route.paramMap.subscribe((params) => {

      this.fragment = params.get('fragment');

    });

  }

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.fragment = params.get('fragment');
    });
    this.getAllCategories();
    this.getAllfeaturedParters()


}

ngAfterViewInit(): void {
  if(this.fragment && this.fragment != '')
  {
  let element = document.getElementById(this.fragment);
    setTimeout(()=>{
      if(element) {
        element.scrollIntoView({behavior: "smooth"});
        //element.scrollIntoView(); // scroll to a particular element
      }
    },1000
    )

    }
}
  getAllCategories() {
      let spname = "get_category_read"
      let ptype = "readallactive"
      let pid = 0
      this.apiservice.apiPost(spname, ptype, pid).subscribe((res: any) => {
      console.log('getAlllCategories', res);
      let temp =res.filter((c: { isleaf: boolean,active:boolean })=>c.isleaf==false && c.active==true)
      this.CategoryList = temp;

    });
  }
  getAllfeaturedParters() {
    let spname = 'featuredd_partner_read';
    this.apiservice.GetAll(spname).subscribe((res: any) => {
      console.log('getAllfeaturedParter', res);

      this.FeaturedPartnerList = res;


    });
  }
}

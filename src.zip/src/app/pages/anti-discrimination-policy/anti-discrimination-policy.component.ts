import { Component } from '@angular/core';

@Component({
  selector: 'app-anti-discrimination-policy',
  templateUrl: './anti-discrimination-policy.component.html',
  styleUrls: ['./anti-discrimination-policy.component.scss']
})
export class AntiDiscriminationPolicyComponent {

}

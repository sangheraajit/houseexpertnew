import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit {
  products: any[] = [];
  responsiveOptions;
  images:any;
  constructor() {


    this.responsiveOptions = [
          {
              breakpoint: '1024px',
              numVisible: 1,
              numScroll: 1
          },
          {
              breakpoint: '768px',
              numVisible: 1,
              numScroll: 1
          },
          {
              breakpoint: '560px',
              numVisible: 1,
              numScroll: 1
          }
      ];
  }

  ngOnInit() {
    this.images = [944, 1011, 984].map((n) => `https://picsum.photos/id/${n}/900/500`);
    this.products = [
      {
        id: "1002",
        code: "zz21cz3c1",
        name: "Discover the property site  Difference.",
        description: "Get your move where you want it, Use House Expert.",
        image: "property.jpg",
         price: 79,
        category: "Fitness",
        quantity: 2,
        inventoryStatus: "LOWSTOCK",
        rating: 3
      },

      {
        id: "1004",
        code: "h456wer53",
        name: "Quotes in Minutes <strong  style='text-align: left; letter-spacing: 0px; font-weight: 700;'>It's That Simple! </strong>",
        description: "Get your move where you want it, Use House Expert.",
        image: "ac.jpg",
         price: 15,
        category: "Accessories",
        quantity: 73,
        inventoryStatus: "INSTOCK",
        rating: 4
      },
      {
        id: "1005",
        code: "av2231fwg",
        name: "Water dripping problem? AC not cooling? Gas leakage? Unusual noise? Don’t wait, Book Service Now. ",
        description: "Regular Servicing leads to the efficient working of AC which in turn leads to power savings.",
        image: "ac1.jpg",
         price: 120,
        category: "Accessories",
        quantity: 0,
        inventoryStatus: "OUTOFSTOCK",
        rating: 4
      },
      {
        id: "1006",
        code: "bib36pfvm",
        name: "The plumber service  Of A New Generation.",
        description: "Get your move where you want it, Use House Expert.",
        image: "plumber.jpg",
         price: 32,
        category: "Accessories",
        quantity: 5,
        inventoryStatus: "LOWSTOCK",
        rating: 3
      },
      {
        id: "1007",
        code: "mbvjkgip5",
        name: "plumber service  perfection at it's finest.",
        description: "Get your move where you want it, Use House Expert.",
        image: "plumber1.jpg",
         price: 34,
        category: "Accessories",
        quantity: 23,
        inventoryStatus: "INSTOCK",
        rating: 5
      },

    ];
  }

}

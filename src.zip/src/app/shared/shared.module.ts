import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FooterComponent, HeaderComponent } from '../layout';
import { SidebarComponent } from '../layout/sidebar/sidebar.component';
import { AngularMaterialModule } from '../angular-material/angular-material.module'
import { MenuModule } from 'primeng/menu';
import { MenubarModule } from 'primeng/menubar';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { StepsModule } from 'primeng/steps';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import {SelectButtonModule} from 'primeng/selectbutton';
import {ButtonModule} from 'primeng/button';
import { HowitComponent } from '../landing/howit/howit.component';
import { GoogleMapsModule } from '@angular/google-maps';
import { CustomGoogleMapsComponent } from './custom-google-maps/custom-google-maps.component';
import { MapComponent } from './map/map.component';
import { CarouselModule } from 'primeng/carousel';
import { SliderComponent } from './slider/slider.component';




@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    AngularMaterialModule,
    MenubarModule,
    MenuModule,
    TieredMenuModule,
    StepsModule,
    DynamicDialogModule,
    SelectButtonModule,
    ButtonModule,
    GoogleMapsModule,
    CarouselModule

  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    HowitComponent,
    CustomGoogleMapsComponent,
    MapComponent,
    SliderComponent,
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    HowitComponent,
    CustomGoogleMapsComponent,
    SliderComponent,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    MenubarModule,
    MenuModule,
    CommonModule,
    AngularMaterialModule,
    GoogleMapsModule,
    ]
})
export class SharedModule { }

export class User {
  Authorization?:      string;
  username?:               string;
  custName?:           string;
  custEmail?:           string;
  custMobile?:              string;
  token!: string;
  isAdmin?: boolean;


}

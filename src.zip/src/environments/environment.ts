export const environment = {
  production: false,
  //CommonApiServer: "http://localhost:5001/api/",
  //AdminServer: "http://localhost:5001",
  //CommonApiServer: "http://188.208.140.246:8095/",
  // AdminServer: "http://103.233.25.27:8082",
  //CommonApiServer: "http://188.208.140.246:8097/",
  // AdminServer: "http://103.87.173.169:8083",
  /* AdminServer: "https://admin.houseexpert.in",
  //CommonApiServer: "https://dev.api.houseexpert.in/",*/
  AdminServer: "https://admin.houseexpert.in",
  CommonApiServer: "https://api.houseexpert.in/",
  ImageserverUrl: "https://api.houseexpert.in/assets/UploadFile/",
  RAZORPAY_KEY_ID:'rzp_test_5kUNZLAhSBYPNy',
  RAZORPAY_KEY_SECRET:'V0sZT8L6KKgNLJZEpnvqnepb',
  //RAZORPAY_KEY_ID:'rzp_live_1STl4OakNI399l',
  //RAZORPAY_KEY_SECRET:'VkCU7CiBbCaGTuHmaZboinBY',

  gstrate: 18,
  insurancerate: 3,
  mobilenumberdisplay: "+91 888 444 9628",
  mobilenumber: "918884449628"
};
